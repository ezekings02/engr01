# -*- coding: utf-8 -*-

#importing required packages
import pandas as pd
from openpyxl import load_workbook


path=r'Data Matching Case Study1.xlsx'
#import data file
table1 = pd.read_excel(path,sheet_name='Table1')

table2 = pd.read_excel(path,sheet_name='Table2')

#preprocessing data (Removing white spaces and lower case value)
table1['Model Name(lower)']=table1['Model Name'].str.strip()
table1['Model Name(lower)']=table1['Model Name(lower)'].str.lower()
table2['Model Name(lower)']=table2['Model Name'].str.strip()
table2['Model Name(lower)']=table2['Model Name(lower)'].str.lower()


#merging both tables based on Model Name
table3 = pd.merge(table2,table1[['Model Name','Record ID','Model Name(lower)']], on='Model Name(lower)')
table3=table3.drop('Model Name(lower)', axis=1)

table3.rename(columns={'Record ID_y':'Record ID (from Table#1)','Record ID_x':'Record ID','Model Name_y':'Model Name(from Table#1)','Model Name_x':'Model Name'}, inplace=True)

#Saving table3 in excel

book = load_workbook(path)
writer = pd.ExcelWriter(path, engine = 'openpyxl')
writer.book = book

table3.to_excel(writer, sheet_name = 'Table3',index = None)
#table2.to_excel(writer, sheet_name = 'x4',index = None)
writer.save()
writer.close()
